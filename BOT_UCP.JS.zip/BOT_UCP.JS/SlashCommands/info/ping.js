const { Client, CommandInteraction } = require("discord.js");

module.exports = {
    name: "",
    description: "",
    type: "",
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
        
    },
};